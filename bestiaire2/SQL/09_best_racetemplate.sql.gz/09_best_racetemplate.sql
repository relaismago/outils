-- phpMyAdmin SQL Dump
-- version 2.6.1
-- http://www.phpmyadmin.net
-- 
-- Serveur: localhost
-- G�n�r� le : Lundi 25 Avril 2005 � 02:45
-- Version du serveur: 4.0.21
-- Version de PHP: 4.3.10
-- 
-- Base de donn�es: `vue2drm`
-- 

-- --------------------------------------------------------

-- 
-- Structure de la table `best_racetemplate`
-- 

DROP TABLE IF EXISTS `best_racetemplate`;
CREATE TABLE `best_racetemplate` (
  `id_race_racetemplate` int(11) NOT NULL default '0',
  `id_template_racetemplate` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id_race_racetemplate`,`id_template_racetemplate`),
  KEY `id_race_racetemplate` (`id_race_racetemplate`),
  KEY `id_template_racetemplate` (`id_template_racetemplate`)
) TYPE=MyISAM;

-- 
-- Contenu de la table `best_racetemplate`
-- 

INSERT INTO `best_racetemplate` (`id_race_racetemplate`, `id_template_racetemplate`) VALUES (12, 25);
INSERT INTO `best_racetemplate` (`id_race_racetemplate`, `id_template_racetemplate`) VALUES (29, 1);
INSERT INTO `best_racetemplate` (`id_race_racetemplate`, `id_template_racetemplate`) VALUES (41, 1);
INSERT INTO `best_racetemplate` (`id_race_racetemplate`, `id_template_racetemplate`) VALUES (41, 15);
INSERT INTO `best_racetemplate` (`id_race_racetemplate`, `id_template_racetemplate`) VALUES (44, 1);
INSERT INTO `best_racetemplate` (`id_race_racetemplate`, `id_template_racetemplate`) VALUES (45, 1);
INSERT INTO `best_racetemplate` (`id_race_racetemplate`, `id_template_racetemplate`) VALUES (50, 9);
INSERT INTO `best_racetemplate` (`id_race_racetemplate`, `id_template_racetemplate`) VALUES (55, 26);
INSERT INTO `best_racetemplate` (`id_race_racetemplate`, `id_template_racetemplate`) VALUES (61, 1);
INSERT INTO `best_racetemplate` (`id_race_racetemplate`, `id_template_racetemplate`) VALUES (62, 1);
INSERT INTO `best_racetemplate` (`id_race_racetemplate`, `id_template_racetemplate`) VALUES (65, 1);
INSERT INTO `best_racetemplate` (`id_race_racetemplate`, `id_template_racetemplate`) VALUES (66, 1);
INSERT INTO `best_racetemplate` (`id_race_racetemplate`, `id_template_racetemplate`) VALUES (70, 1);
INSERT INTO `best_racetemplate` (`id_race_racetemplate`, `id_template_racetemplate`) VALUES (70, 12);
INSERT INTO `best_racetemplate` (`id_race_racetemplate`, `id_template_racetemplate`) VALUES (72, 1);
INSERT INTO `best_racetemplate` (`id_race_racetemplate`, `id_template_racetemplate`) VALUES (87, 1);
INSERT INTO `best_racetemplate` (`id_race_racetemplate`, `id_template_racetemplate`) VALUES (89, 1);
INSERT INTO `best_racetemplate` (`id_race_racetemplate`, `id_template_racetemplate`) VALUES (98, 1);
INSERT INTO `best_racetemplate` (`id_race_racetemplate`, `id_template_racetemplate`) VALUES (101, 1);
INSERT INTO `best_racetemplate` (`id_race_racetemplate`, `id_template_racetemplate`) VALUES (108, 1);
INSERT INTO `best_racetemplate` (`id_race_racetemplate`, `id_template_racetemplate`) VALUES (108, 46);
INSERT INTO `best_racetemplate` (`id_race_racetemplate`, `id_template_racetemplate`) VALUES (109, 31);
INSERT INTO `best_racetemplate` (`id_race_racetemplate`, `id_template_racetemplate`) VALUES (111, 22);
INSERT INTO `best_racetemplate` (`id_race_racetemplate`, `id_template_racetemplate`) VALUES (118, 1);
INSERT INTO `best_racetemplate` (`id_race_racetemplate`, `id_template_racetemplate`) VALUES (121, 3);
INSERT INTO `best_racetemplate` (`id_race_racetemplate`, `id_template_racetemplate`) VALUES (124, 1);
INSERT INTO `best_racetemplate` (`id_race_racetemplate`, `id_template_racetemplate`) VALUES (132, 1);
INSERT INTO `best_racetemplate` (`id_race_racetemplate`, `id_template_racetemplate`) VALUES (137, 1);
INSERT INTO `best_racetemplate` (`id_race_racetemplate`, `id_template_racetemplate`) VALUES (139, 1);
