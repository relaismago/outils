-- phpMyAdmin SQL Dump
-- version 2.6.1
-- http://www.phpmyadmin.net
-- 
-- Serveur: localhost
-- G�n�r� le : Lundi 25 Avril 2005 � 02:44
-- Version du serveur: 4.0.21
-- Version de PHP: 4.3.10
-- 
-- Base de donn�es: `vue2drm`
-- 

-- --------------------------------------------------------

-- 
-- Structure de la table `best_capspe`
-- 

DROP TABLE IF EXISTS `best_capspe`;
CREATE TABLE `best_capspe` (
  `id_monstre_capspe` int(11) NOT NULL default '0',
  `id_race_capspe` int(11) NOT NULL default '0',
  `id_template_capspe` int(11) NOT NULL default '0',
  `id_age_capspe` int(11) NOT NULL default '0',
  `nom_capspe` varchar(64) NOT NULL default '',
  `affecte_capspe` varchar(128) NOT NULL default '',
  `MMsom_capspe` int(11) NOT NULL default '0',
  `MMnbr_capspe` int(11) NOT NULL default '0',
  `degatssom_capspe` int(11) NOT NULL default '0',
  `degatsnbr_capspe` int(11) NOT NULL default '0',
  `portee_capspe` tinyint(3) NOT NULL default '0',
  `duree_capspe` enum('?','0','1','2','3','4','5','6','7','8','9') NOT NULL default '?',
  `sepatt_capspe` enum('?','Oui','Non') NOT NULL default '?',
  `zone_capspe` enum('?','Oui','Non') NOT NULL default '?',
  `portee_zone_capspe` tinyint(3) NOT NULL default '0',
  `date_capspe` timestamp(14) NOT NULL,
  `source_capspe` varchar(30) NOT NULL default 'Relais & Mago',
  PRIMARY KEY  (`id_monstre_capspe`),
  KEY `Race` (`id_race_capspe`),
  KEY `Template` (`id_template_capspe`),
  KEY `Age` (`id_age_capspe`)
) TYPE=MyISAM COMMENT='capacit� sp�ciale des monstres';

-- 
-- Contenu de la table `best_capspe`
-- 

INSERT INTO `best_capspe` (`id_monstre_capspe`, `id_race_capspe`, `id_template_capspe`, `id_age_capspe`, `nom_capspe`, `affecte_capspe`, `MMsom_capspe`, `MMnbr_capspe`, `degatssom_capspe`, `degatsnbr_capspe`, `portee_capspe`, `duree_capspe`, `sepatt_capspe`, `zone_capspe`, `portee_zone_capspe`, `date_capspe`, `source_capspe`) VALUES (1, 55, 26, 5, 'Maladie', 'D�gats | R�g�n�ration', 0, 0, 0, 0, 0, '?', '?', '?', 0, '20050425001154', 'Dralik');
INSERT INTO `best_capspe` (`id_monstre_capspe`, `id_race_capspe`, `id_template_capspe`, `id_age_capspe`, `nom_capspe`, `affecte_capspe`, `MMsom_capspe`, `MMnbr_capspe`, `degatssom_capspe`, `degatsnbr_capspe`, `portee_capspe`, `duree_capspe`, `sepatt_capspe`, `zone_capspe`, `portee_zone_capspe`, `date_capspe`, `source_capspe`) VALUES (5, 29, 1, 9, 'Coup Perforant', 'Armure', 0, 0, 0, 0, 0, '?', '?', '?', 0, '20050425012405', 'Dralik');
INSERT INTO `best_capspe` (`id_monstre_capspe`, `id_race_capspe`, `id_template_capspe`, `id_age_capspe`, `nom_capspe`, `affecte_capspe`, `MMsom_capspe`, `MMnbr_capspe`, `degatssom_capspe`, `degatsnbr_capspe`, `portee_capspe`, `duree_capspe`, `sepatt_capspe`, `zone_capspe`, `portee_zone_capspe`, `date_capspe`, `source_capspe`) VALUES (6, 41, 1, 9, 'Attaque Electrique', 'Attaque', 0, 0, 0, 0, 0, '?', '?', '?', 0, '20050425014257', 'Dralik');
INSERT INTO `best_capspe` (`id_monstre_capspe`, `id_race_capspe`, `id_template_capspe`, `id_age_capspe`, `nom_capspe`, `affecte_capspe`, `MMsom_capspe`, `MMnbr_capspe`, `degatssom_capspe`, `degatsnbr_capspe`, `portee_capspe`, `duree_capspe`, `sepatt_capspe`, `zone_capspe`, `portee_zone_capspe`, `date_capspe`, `source_capspe`) VALUES (7, 41, 1, 10, 'Attaque Electrique', 'Attaque', 0, 0, 0, 0, 0, '?', '?', '?', 0, '20050425014444', 'Dralik');
INSERT INTO `best_capspe` (`id_monstre_capspe`, `id_race_capspe`, `id_template_capspe`, `id_age_capspe`, `nom_capspe`, `affecte_capspe`, `MMsom_capspe`, `MMnbr_capspe`, `degatssom_capspe`, `degatsnbr_capspe`, `portee_capspe`, `duree_capspe`, `sepatt_capspe`, `zone_capspe`, `portee_zone_capspe`, `date_capspe`, `source_capspe`) VALUES (8, 41, 1, 14, 'Attaque Electrique', 'Attaque', 0, 0, 0, 0, 0, '?', '?', '?', 0, '20050425014713', 'Dralik');
INSERT INTO `best_capspe` (`id_monstre_capspe`, `id_race_capspe`, `id_template_capspe`, `id_age_capspe`, `nom_capspe`, `affecte_capspe`, `MMsom_capspe`, `MMnbr_capspe`, `degatssom_capspe`, `degatsnbr_capspe`, `portee_capspe`, `duree_capspe`, `sepatt_capspe`, `zone_capspe`, `portee_zone_capspe`, `date_capspe`, `source_capspe`) VALUES (9, 41, 15, 16, 'Attaque Electrique', 'Attaque', 0, 0, 0, 0, 0, '?', '?', '?', 0, '20050425015026', 'Dralik');
INSERT INTO `best_capspe` (`id_monstre_capspe`, `id_race_capspe`, `id_template_capspe`, `id_age_capspe`, `nom_capspe`, `affecte_capspe`, `MMsom_capspe`, `MMnbr_capspe`, `degatssom_capspe`, `degatsnbr_capspe`, `portee_capspe`, `duree_capspe`, `sepatt_capspe`, `zone_capspe`, `portee_zone_capspe`, `date_capspe`, `source_capspe`) VALUES (10, 44, 1, 9, 'Attaque Etourdissante', 'DLA', 0, 0, 0, 0, 0, '?', '?', '?', 0, '20050425015133', 'Dralik');
INSERT INTO `best_capspe` (`id_monstre_capspe`, `id_race_capspe`, `id_template_capspe`, `id_age_capspe`, `nom_capspe`, `affecte_capspe`, `MMsom_capspe`, `MMnbr_capspe`, `degatssom_capspe`, `degatsnbr_capspe`, `portee_capspe`, `duree_capspe`, `sepatt_capspe`, `zone_capspe`, `portee_zone_capspe`, `date_capspe`, `source_capspe`) VALUES (12, 111, 22, 9, 'Coup Perforant', 'Armure', 0, 0, 0, 0, 0, '?', '?', '?', 0, '20050425015701', 'Dralik');
INSERT INTO `best_capspe` (`id_monstre_capspe`, `id_race_capspe`, `id_template_capspe`, `id_age_capspe`, `nom_capspe`, `affecte_capspe`, `MMsom_capspe`, `MMnbr_capspe`, `degatssom_capspe`, `degatsnbr_capspe`, `portee_capspe`, `duree_capspe`, `sepatt_capspe`, `zone_capspe`, `portee_zone_capspe`, `date_capspe`, `source_capspe`) VALUES (13, 89, 1, 9, 'Constriction', 'Attaque | Esquive | R�g�n�ration', 0, 0, 0, 0, 0, '?', '?', '?', 0, '20050425015847', 'Dralik');
INSERT INTO `best_capspe` (`id_monstre_capspe`, `id_race_capspe`, `id_template_capspe`, `id_age_capspe`, `nom_capspe`, `affecte_capspe`, `MMsom_capspe`, `MMnbr_capspe`, `degatssom_capspe`, `degatsnbr_capspe`, `portee_capspe`, `duree_capspe`, `sepatt_capspe`, `zone_capspe`, `portee_zone_capspe`, `date_capspe`, `source_capspe`) VALUES (14, 108, 1, 9, 'Souffle de Feu', 'PV', 0, 0, 0, 0, 0, '?', '?', '?', 0, '20050425020156', 'Dralik');
INSERT INTO `best_capspe` (`id_monstre_capspe`, `id_race_capspe`, `id_template_capspe`, `id_age_capspe`, `nom_capspe`, `affecte_capspe`, `MMsom_capspe`, `MMnbr_capspe`, `degatssom_capspe`, `degatsnbr_capspe`, `portee_capspe`, `duree_capspe`, `sepatt_capspe`, `zone_capspe`, `portee_zone_capspe`, `date_capspe`, `source_capspe`) VALUES (15, 108, 1, 10, 'Souffle de Feu', 'PV', 0, 0, 0, 0, 0, '?', '?', '?', 0, '20050425020335', 'Dralik');
INSERT INTO `best_capspe` (`id_monstre_capspe`, `id_race_capspe`, `id_template_capspe`, `id_age_capspe`, `nom_capspe`, `affecte_capspe`, `MMsom_capspe`, `MMnbr_capspe`, `degatssom_capspe`, `degatsnbr_capspe`, `portee_capspe`, `duree_capspe`, `sepatt_capspe`, `zone_capspe`, `portee_zone_capspe`, `date_capspe`, `source_capspe`) VALUES (16, 108, 46, 10, 'Souffle de Feu', 'PV', 0, 0, 0, 0, 0, '?', '?', '?', 0, '20050425020348', 'Dralik');
INSERT INTO `best_capspe` (`id_monstre_capspe`, `id_race_capspe`, `id_template_capspe`, `id_age_capspe`, `nom_capspe`, `affecte_capspe`, `MMsom_capspe`, `MMnbr_capspe`, `degatssom_capspe`, `degatsnbr_capspe`, `portee_capspe`, `duree_capspe`, `sepatt_capspe`, `zone_capspe`, `portee_zone_capspe`, `date_capspe`, `source_capspe`) VALUES (17, 118, 1, 9, 'Aura de Feu', 'PV', 0, 0, 0, 0, 0, '?', '?', '?', 0, '20050425023514', 'Dralik');
INSERT INTO `best_capspe` (`id_monstre_capspe`, `id_race_capspe`, `id_template_capspe`, `id_age_capspe`, `nom_capspe`, `affecte_capspe`, `MMsom_capspe`, `MMnbr_capspe`, `degatssom_capspe`, `degatsnbr_capspe`, `portee_capspe`, `duree_capspe`, `sepatt_capspe`, `zone_capspe`, `portee_zone_capspe`, `date_capspe`, `source_capspe`) VALUES (19, 72, 1, 24, 'Attaque Electrique', 'Attaque', 0, 0, 0, 0, 0, '?', '?', '?', 0, '20050425023618', 'Dralik');
INSERT INTO `best_capspe` (`id_monstre_capspe`, `id_race_capspe`, `id_template_capspe`, `id_age_capspe`, `nom_capspe`, `affecte_capspe`, `MMsom_capspe`, `MMnbr_capspe`, `degatssom_capspe`, `degatsnbr_capspe`, `portee_capspe`, `duree_capspe`, `sepatt_capspe`, `zone_capspe`, `portee_zone_capspe`, `date_capspe`, `source_capspe`) VALUES (20, 72, 1, 17, 'Attaque Electrique', 'Attaque', 0, 0, 0, 0, 0, '?', '?', '?', 0, '20050425023629', 'Dralik');
INSERT INTO `best_capspe` (`id_monstre_capspe`, `id_race_capspe`, `id_template_capspe`, `id_age_capspe`, `nom_capspe`, `affecte_capspe`, `MMsom_capspe`, `MMnbr_capspe`, `degatssom_capspe`, `degatsnbr_capspe`, `portee_capspe`, `duree_capspe`, `sepatt_capspe`, `zone_capspe`, `portee_zone_capspe`, `date_capspe`, `source_capspe`) VALUES (24, 121, 3, 24, 'Charme', 'Attaque | Esquive | Vue', 0, 0, 0, 0, 0, '?', '?', '?', 0, '20050425023805', 'Dralik');
INSERT INTO `best_capspe` (`id_monstre_capspe`, `id_race_capspe`, `id_template_capspe`, `id_age_capspe`, `nom_capspe`, `affecte_capspe`, `MMsom_capspe`, `MMnbr_capspe`, `degatssom_capspe`, `degatsnbr_capspe`, `portee_capspe`, `duree_capspe`, `sepatt_capspe`, `zone_capspe`, `portee_zone_capspe`, `date_capspe`, `source_capspe`) VALUES (25, 87, 1, 29, 'Venin Virulent', 'PV', 0, 0, 0, 0, 0, '?', '?', '?', 0, '20050425023844', 'Dralik');
INSERT INTO `best_capspe` (`id_monstre_capspe`, `id_race_capspe`, `id_template_capspe`, `id_age_capspe`, `nom_capspe`, `affecte_capspe`, `MMsom_capspe`, `MMnbr_capspe`, `degatssom_capspe`, `degatsnbr_capspe`, `portee_capspe`, `duree_capspe`, `sepatt_capspe`, `zone_capspe`, `portee_zone_capspe`, `date_capspe`, `source_capspe`) VALUES (26, 87, 1, 25, 'Venin Virulent', 'PV', 0, 0, 0, 0, 0, '?', '?', '?', 0, '20050425023853', 'Dralik');
INSERT INTO `best_capspe` (`id_monstre_capspe`, `id_race_capspe`, `id_template_capspe`, `id_age_capspe`, `nom_capspe`, `affecte_capspe`, `MMsom_capspe`, `MMnbr_capspe`, `degatssom_capspe`, `degatsnbr_capspe`, `portee_capspe`, `duree_capspe`, `sepatt_capspe`, `zone_capspe`, `portee_zone_capspe`, `date_capspe`, `source_capspe`) VALUES (27, 124, 1, 25, 'Drain de vie', 'R�g�n�ration | PV', 0, 0, 0, 0, 0, '?', '?', '?', 0, '20050425023901', 'Dralik');
INSERT INTO `best_capspe` (`id_monstre_capspe`, `id_race_capspe`, `id_template_capspe`, `id_age_capspe`, `nom_capspe`, `affecte_capspe`, `MMsom_capspe`, `MMnbr_capspe`, `degatssom_capspe`, `degatsnbr_capspe`, `portee_capspe`, `duree_capspe`, `sepatt_capspe`, `zone_capspe`, `portee_zone_capspe`, `date_capspe`, `source_capspe`) VALUES (28, 50, 9, 33, 'Aura de Feu', 'PV', 0, 0, 0, 0, 0, '?', '?', '?', 0, '20050425023911', 'Dralik');
INSERT INTO `best_capspe` (`id_monstre_capspe`, `id_race_capspe`, `id_template_capspe`, `id_age_capspe`, `nom_capspe`, `affecte_capspe`, `MMsom_capspe`, `MMnbr_capspe`, `degatssom_capspe`, `degatsnbr_capspe`, `portee_capspe`, `duree_capspe`, `sepatt_capspe`, `zone_capspe`, `portee_zone_capspe`, `date_capspe`, `source_capspe`) VALUES (29, 70, 1, 33, 'Constriction', 'Attaque | Esquive | R�g�n�ration', 0, 0, 0, 0, 0, '?', '?', '?', 0, '20050425023922', 'Dralik');
INSERT INTO `best_capspe` (`id_monstre_capspe`, `id_race_capspe`, `id_template_capspe`, `id_age_capspe`, `nom_capspe`, `affecte_capspe`, `MMsom_capspe`, `MMnbr_capspe`, `degatssom_capspe`, `degatsnbr_capspe`, `portee_capspe`, `duree_capspe`, `sepatt_capspe`, `zone_capspe`, `portee_zone_capspe`, `date_capspe`, `source_capspe`) VALUES (30, 70, 12, 33, 'Constriction', 'Attaque | Esquive | R�g�n�ration', 0, 0, 0, 0, 0, '?', '?', '?', 0, '20050425023931', 'Dralik');
INSERT INTO `best_capspe` (`id_monstre_capspe`, `id_race_capspe`, `id_template_capspe`, `id_age_capspe`, `nom_capspe`, `affecte_capspe`, `MMsom_capspe`, `MMnbr_capspe`, `degatssom_capspe`, `degatsnbr_capspe`, `portee_capspe`, `duree_capspe`, `sepatt_capspe`, `zone_capspe`, `portee_zone_capspe`, `date_capspe`, `source_capspe`) VALUES (31, 98, 1, 34, 'Venin', 'PV', 0, 0, 0, 0, 0, '?', '?', '?', 0, '20050425023941', 'Dralik');
INSERT INTO `best_capspe` (`id_monstre_capspe`, `id_race_capspe`, `id_template_capspe`, `id_age_capspe`, `nom_capspe`, `affecte_capspe`, `MMsom_capspe`, `MMnbr_capspe`, `degatssom_capspe`, `degatsnbr_capspe`, `portee_capspe`, `duree_capspe`, `sepatt_capspe`, `zone_capspe`, `portee_zone_capspe`, `date_capspe`, `source_capspe`) VALUES (32, 98, 1, 33, 'Venin', 'PV', 0, 0, 0, 0, 0, '?', '?', '?', 0, '20050425023949', 'Dralik');
INSERT INTO `best_capspe` (`id_monstre_capspe`, `id_race_capspe`, `id_template_capspe`, `id_age_capspe`, `nom_capspe`, `affecte_capspe`, `MMsom_capspe`, `MMnbr_capspe`, `degatssom_capspe`, `degatsnbr_capspe`, `portee_capspe`, `duree_capspe`, `sepatt_capspe`, `zone_capspe`, `portee_zone_capspe`, `date_capspe`, `source_capspe`) VALUES (33, 109, 31, 34, 'Aura Vengeresse', 'PV', 0, 0, 0, 0, 0, '?', '?', '?', 0, '20050425024002', 'Dralik');
INSERT INTO `best_capspe` (`id_monstre_capspe`, `id_race_capspe`, `id_template_capspe`, `id_age_capspe`, `nom_capspe`, `affecte_capspe`, `MMsom_capspe`, `MMnbr_capspe`, `degatssom_capspe`, `degatsnbr_capspe`, `portee_capspe`, `duree_capspe`, `sepatt_capspe`, `zone_capspe`, `portee_zone_capspe`, `date_capspe`, `source_capspe`) VALUES (34, 132, 1, 33, 'Coup Perforant', 'Armure', 0, 0, 0, 0, 0, '?', '?', '?', 0, '20050425024029', 'Dralik');
INSERT INTO `best_capspe` (`id_monstre_capspe`, `id_race_capspe`, `id_template_capspe`, `id_age_capspe`, `nom_capspe`, `affecte_capspe`, `MMsom_capspe`, `MMnbr_capspe`, `degatssom_capspe`, `degatsnbr_capspe`, `portee_capspe`, `duree_capspe`, `sepatt_capspe`, `zone_capspe`, `portee_zone_capspe`, `date_capspe`, `source_capspe`) VALUES (35, 137, 1, 40, 'Venin', 'PV', 0, 0, 0, 0, 0, '?', '?', '?', 0, '20050425024038', 'Dralik');
INSERT INTO `best_capspe` (`id_monstre_capspe`, `id_race_capspe`, `id_template_capspe`, `id_age_capspe`, `nom_capspe`, `affecte_capspe`, `MMsom_capspe`, `MMnbr_capspe`, `degatssom_capspe`, `degatsnbr_capspe`, `portee_capspe`, `duree_capspe`, `sepatt_capspe`, `zone_capspe`, `portee_zone_capspe`, `date_capspe`, `source_capspe`) VALUES (36, 12, 25, 41, 'Charme', 'Attaque | Esquive | Vue', 0, 0, 0, 0, 0, '?', '?', '?', 0, '20050425024058', 'Dralik');
INSERT INTO `best_capspe` (`id_monstre_capspe`, `id_race_capspe`, `id_template_capspe`, `id_age_capspe`, `nom_capspe`, `affecte_capspe`, `MMsom_capspe`, `MMnbr_capspe`, `degatssom_capspe`, `degatsnbr_capspe`, `portee_capspe`, `duree_capspe`, `sepatt_capspe`, `zone_capspe`, `portee_zone_capspe`, `date_capspe`, `source_capspe`) VALUES (37, 101, 1, 41, 'Venin', 'PV', 0, 0, 0, 0, 0, '?', '?', '?', 0, '20050425024117', 'Dralik');
