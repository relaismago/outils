-- phpMyAdmin SQL Dump
-- version 2.6.1
-- http://www.phpmyadmin.net
-- 
-- Serveur: localhost
-- G�n�r� le : Lundi 25 Avril 2005 � 02:47
-- Version du serveur: 4.0.21
-- Version de PHP: 4.3.10
-- 
-- Base de donn�es: `vue2drm`
-- 

-- --------------------------------------------------------

-- 
-- Structure de la table `best_caracs`
-- 

DROP TABLE IF EXISTS `best_caracs`;
CREATE TABLE `best_caracs` (
  `id_monstre_caracs` int(11) NOT NULL default '0',
  `id_race_caracs` int(11) NOT NULL default '0',
  `id_template_caracs` int(11) NOT NULL default '0',
  `id_age_caracs` int(11) NOT NULL default '0',
  `RMsom_caracs` int(11) NOT NULL default '0',
  `RMnbr_caracs` int(11) NOT NULL default '0',
  `source_caracs` varchar(30) NOT NULL default '',
  `date_caracs` timestamp(14) NOT NULL,
  PRIMARY KEY  (`id_monstre_caracs`),
  KEY `id_race_caracs` (`id_race_caracs`,`id_template_caracs`,`id_age_caracs`)
) TYPE=MyISAM COMMENT='autres caracs des monstres (RM)';

-- 
-- Contenu de la table `best_caracs`
-- 

